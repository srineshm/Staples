import java.util.Scanner;

public class staples {

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in); 
		
		int copies;
		double price, total; 
		System.out.printf("%-27s%-20s\n", "Copies", "Cost");
		System.out.printf("%-27s%-20s\n", "1-99", "$0.30 per copy");
		System.out.printf("%-27s%-20s\n", "100-499", "$0.28 per copy");
		System.out.printf("%-27s%-20s\n", "500-749", "$0.28 per copy");
		System.out.printf("%-27s%-20s\n", "750-100", "$0.26 per copy");
		System.out.printf("%-27s%-20s\n", "> 1000", "$0.25 per copy");
		
		System.out.printf("%-27s","Enter number of copies:");
		copies = input.nextInt();
		
		if (copies<= 99) {
			price = 0.30;
		}
		else if (copies<=499) {
			price = 0.28; 
		}
		
		else if (copies<=749) {
			price = 0.27; 
		}
		
		else if (copies<=1000) {
			price = 0.26; 
		}

		else {
			price = 0.25; 
		} 
	
    total = copies * price;
    System.out.printf("%-27s", "Price for " + copies + " copies @ $" + price + "/copy");
    System.out.println("\nTotal cost: $" + total);
	
		
	}
		
	}
	


